WEBTE1
ZÁPOCET 1
MICHELANGELO

Vytvorte stránku presne podla predlohy:
https://webteh.fei.stuba.sk/~xsefcikj/MicheLangelo

ZS 25/26
→ tulipán má romery w: 100px, h: 200px s margin: 20px na vsetky strany
→ stopka má w: 10px, h: 120px, rádius: 5px → plod má w: 90px, h: 55px, rádius: 0 0 90px 90px → lupienky plodu maju w: 30px, border L+R: 15px, border Bot:
30px
→ list w: 50px, h: 50px, rádius: 100% 0% 100% 0% → listy musia byt v jednej úrovni
→ kontajner vely má rovnaké romery ako tulipán (bod c.1)
→ telo vely má w: 120px, h: 80px
→ bodák veely má border T+B: 8px, border L: 20px → krídla majú w: 30px, h: 60px, rádius: 50% 50% 0 0 → krídla sú otocené o 20 stupñov
→ po prejdení kurzorom sa tulipán zafarbí inou farbou → po prejdení kurzorom sa vela posunie o 50% nahor
→ "záhrada" musí byt responzívna vid. gif
→ Pri hover efekte sa nesmie narusit layout stránky, elementy nesmú
"poskakovat"
→ Funkcionalita nabehnutia mysou musí ostat zachovaná pri vsetkých
Jirkach zobrazenia.

Meno a priezvisko: David Tsofin
