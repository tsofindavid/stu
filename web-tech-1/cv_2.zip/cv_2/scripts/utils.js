function getErrorId(field) {
  return `${field}Error`;
}
